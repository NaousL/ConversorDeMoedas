package com.example.primeiroaplicativo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ViewHolder mViewHolder = new ViewHolder();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mViewHolder.editValue =  findViewById(R.id.edit_value);
        this.mViewHolder.textDollar =  findViewById(R.id.text_dollar);
        this.mViewHolder.textEuro =  findViewById(R.id.text_euro);
        this.mViewHolder.textLibra =  findViewById(R.id.text_libra);
        this.mViewHolder.buttonCalculate =  findViewById(R.id.button_calculate);

        this.mViewHolder.buttonCalculate.setOnClickListener(this);

        this.ClearValues();
    }

    @Override
    public void onClick(View view) {
        double id = view.getId();
        if (id == R.id.button_calculate){
            //Lógica do Botão
        Double value =  Double.valueOf(this.mViewHolder.editValue.getText().toString());
        this.mViewHolder.textDollar.setText(String.format("%.2f", value / 4.08));
            this.mViewHolder.textEuro.setText(String.format("%.2f", value / 4.52));
            this.mViewHolder.textLibra.setText(String.format("%.2f", value / 5.10));


        }

    }

    private void ClearValues(){
        this.mViewHolder.textDollar.setText("");
        this.mViewHolder.textEuro.setText("");
        this.mViewHolder.textLibra.setText("");
    }

    private static class ViewHolder{
        TextView textLibra;
        EditText editValue;
        TextView textDollar;
        TextView textEuro;
        Button buttonCalculate;

    }
}